import { Routes } from '@angular/router';
import { LoginComponent } from './component/login/login.component';
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { LayoutComponent } from './component/layout/layout.component';
import { SaveRequestComponent } from './save-request/save-request.component';
import { SearchRequestComponent } from './search-request/search-request.component';
import { BatchComponent } from './batch/batch.component';
import { RequestStatusComponent } from './request-status/request-status.component';

export const routes: Routes = [

{
    path:"login", component: LoginComponent
},
{
    path:"home", component: DashboardComponent 
},
{
    path:"layout", component: LayoutComponent 
},
{
    path:"save-request", component: SaveRequestComponent 
},
{
    path:"search-request", component: SearchRequestComponent 
},
{
    path:"batch", component: BatchComponent 
},
{
    path:"request-status", component: RequestStatusComponent 
}
];
