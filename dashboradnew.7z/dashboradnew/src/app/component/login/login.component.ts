import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [FormsModule,RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginObj:loginModel = new loginModel();
   loginForm() {
    
    const localusers = localStorage.getItem('users');
    
    if(localusers !=null) {
      const users =JSON.parse(localusers);
      users.push(this.loginObj);
      localStorage.setItem('users',JSON.stringify(users) );
      console.log("login successful",localusers);
    }else {
      const users= [];
      users.push(this.loginObj);
      localStorage.setItem('users',JSON.stringify(users) );
      console.log("login successful",localusers);
    }
  }
}

export class loginModel {
  email:string;
  password:string;
  constructor(){
    this.email = "";
    this.password = "";
  }
}



