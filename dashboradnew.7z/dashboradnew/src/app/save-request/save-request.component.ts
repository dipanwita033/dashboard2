import { Component, inject } from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import {MatDividerModule} from '@angular/material/divider';
import { RouterLink } from '@angular/router';


@Component({
  selector: 'app-save-request',
  imports: [ReactiveFormsModule,MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatCardModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatDividerModule,RouterLink],
  templateUrl: './save-request.component.html',
  styleUrl: './save-request.component.css'
})
export class SaveRequestComponent {
  //private formBuilder = inject(FormBuilder);
  
  profileForm = new FormGroup({
    investorId: new FormControl(''),
    periodStartDate: new FormControl(''),
    periodEndDate: new FormControl(''),

    sentToPrint: new FormControl(''),
    sentToAlfresco: new FormControl(''),
    exceptionOverride: new FormControl(''),

    includeTaxVoucher: new FormControl(''),    
    includeCoca: new FormControl(''),
   
  });
  saveForm(){
    console.log('Form data is ', this.profileForm.value);
  }
}
