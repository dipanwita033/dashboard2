import { Component } from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import {MatDividerModule} from '@angular/material/divider';
import {NgIf} from '@angular/common';
import {MatTableModule} from '@angular/material/table';

@Component({
  selector: 'app-batch',
  imports: [ReactiveFormsModule,MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatCardModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatDividerModule,MatTableModule,NgIf],
  templateUrl: './batch.component.html',
  styleUrl: './batch.component.css'
})
export class BatchComponent {
isDisplay = false;
  profileForm = new FormGroup({
    name: new FormControl(''),
    date: new FormControl(''),
    status: new FormControl(''),

    

  });
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  

  saveForm(){
    console.log('Form data is ', this.profileForm.value);
    this.isDisplay = true;
  }
}
